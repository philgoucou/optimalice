# Generate graphs for ICE+
# ----------------------------------------------------------------
# Creation: 08/22/2019
# Last modified: 08/20/2021
# ----------------------------------------------------------------


# =========================================================================== #
#                             INITIALIZATION
# =========================================================================== #

# Clear workspace 
rm(list = ls())
graphics.off()

# packages
library(ggplot2)
library(reshape2)
library(tidyverse)
library(latex2exp)

# working directory for the Replication Files
wd = '~/ICEplus/ReplicationFiles'

setwd(wd)

# auxiliary subfunctions
source('./code/tools.R')

# load sea ice extent indicators and ICE+
iceplus_dts = iceplus_dts = read.csv("./data/ice_with_dts_latent_addIntercept.csv") # this is the ice+ extracted from DFM
colnames(iceplus_dts)[3:6] = c("SII", "JAXA", "Bremen", "Goddard")

# create a column for date
start_year  = iceplus_dts$Year[1]
start_month = iceplus_dts$Month[1]
end_year    = iceplus_dts$Year[nrow(iceplus_dts)]
end_month   = iceplus_dts$Month[nrow(iceplus_dts)]

iceplus_dts$Date = seq(start_year + (start_month-1)/12, end_year + (end_month-1)/12, by = 1/12)


#########################################################################################
# Figure 1, upper panel: Four Sea Ice Extent Indicators
#########################################################################################
mat_raw_data = melt(iceplus_dts[,c(3,4,5,6,9)],id.vars = 'Date')

# png(file = ..., width = 1500, height = 500, res = 200)

ggplot(data = mat_raw_data, aes(x = Date, y = value, col = variable)) +
   geom_line(size = 0.3, alpha = 0.7) +
   xlab('') + ylab('Sea Ice Extent') + ylim(4, 16) +
   scale_x_continuous(breaks = seq(1980, 2020, by = 5), limits = c(1979, 2020), expand = c(0,0.5))+
   theme_bw()+
   theme(legend.position="bottom", legend.title=element_blank(), legend.text = element_text(size = 10)) +
   guides(color = guide_legend(override.aes = list(size = 1)))

# dev.off()



#########################################################################################
# Figure 1, lower panel: Four Sea Ice Extent Indicators, by month
#########################################################################################

mat_extent_and_ice = cbind(iceplus_dts[, 1:6])

mat_melt = reshape2::melt(mat_extent_and_ice, id.vars = c('Year','Month'))
mat_melt$Month = month.name[mat_melt$Month]
mat_melt$Month = factor(mat_melt$Month, levels = month.name)

# png(file = ..., width = 1800, height = 2000, res = 250)

ggplot(data = mat_melt, aes(x = Year, y = value, col = variable)) +
   geom_line(size = 0.5, alpha = 0.7) +
   facet_wrap( ~ Month, ncol = 3, scale = 'free_y') +
   scale_y_continuous(breaks = breaks_fun) +
   scale_x_continuous(breaks = seq(1980, 2020, 10), minor_breaks = NULL, limits = c(1979, 2021)) +
   xlab('') + ylab('Sea Ice Extent') +
   theme_bw() +
   theme(legend.position = "bottom", legend.title = element_blank(), legend.text = element_text(size = 12)) +
   guides(color = guide_legend(override.aes = list(size = 1)))

# dev.off()


#########################################################################################
# Figure 2: Extracted Sea Ice Extents and Four Raw Indicators, by Month, lambda_S = 1
#########################################################################################

mat_extent_and_ice = cbind(iceplus_dts[, 1:7])
set.seed(1)
mat_extent_and_ice$SII = mat_extent_and_ice$SII + rnorm(length(mat_extent_and_ice$SII), 0, 0.1)
colnames(mat_extent_and_ice)[7] = 'Extracted'

mat_melt = reshape2::melt(mat_extent_and_ice, id.vars = c('Year','Month'))
mat_melt$Month = month.name[mat_melt$Month]
mat_melt$Month = factor(mat_melt$Month, levels = month.name)
mat_melt$LineSize = rep(rep(c(0.4,0.4,0.4,0.4,0.4), each = 40), times = 12)

# png(file = ..., width = 1800, height = 2000, res = 250)

ggplot(data = mat_melt, aes(x = Year, y = value, col = variable)) +
   geom_line(size = mat_melt$LineSize, alpha = 0.7) +
   scale_y_continuous(breaks = breaks_fun) +
   scale_x_continuous(breaks = seq(1980, 2020, 10), minor_breaks = NULL, limits = c(1979, 2021)) +
   facet_wrap( ~ Month, ncol = 3, scale = 'free_y') +
   xlab('') + ylab('Sea Ice Extent') +
   theme_bw() +
   theme(legend.position = "bottom", legend.title = element_blank(), legend.text = element_text(size = 12)) +
   guides(color = guide_legend(override.aes = list(size = c(0.4,0.4,0.4,0.4,0.8)))) +
   scale_color_manual(values = c(gg_color_hue(4),'black'))

# dev.off()


#########################################################################################
# Figure 3: Extracted Sea Ice Extents and Four Raw Indicators, by Month, lambda_G = 1
#########################################################################################

mat_extent_and_ice = cbind(iceplus_dts[, c(1:6,8)])
colnames(mat_extent_and_ice)[7] = 'Extracted'

mat_melt = reshape2::melt(mat_extent_and_ice, id.vars = c('Year','Month'))
mat_melt$Month = month.name[mat_melt$Month]
mat_melt$Month = factor(mat_melt$Month, levels = month.name)
mat_melt$LineSize = rep(rep(c(0.4,0.4,0.4,0.4,0.4), each = 40), times = 12)

# png(file = ..., width = 1800, height = 2000, res = 250)

ggplot(data = mat_melt, aes(x = Year, y = value, col = variable)) +
   geom_line(size = mat_melt$LineSize, alpha = 0.7) +
   scale_y_continuous(breaks = breaks_fun) +
   scale_x_continuous(breaks = seq(1980, 2020, 10), minor_breaks = NULL, limits = c(1979, 2021)) +
   facet_wrap( ~ Month, ncol = 3, scale = 'free_y') +
   xlab('') + ylab('Sea Ice Extent') +
   theme_bw() +
   theme(legend.position = "bottom", legend.title = element_blank(), legend.text = element_text(size = 12)) +
   guides(color = guide_legend(override.aes = list(size = c(0.4,0.4,0.4,0.4,0.8)))) +
   scale_color_manual(values = c(gg_color_hue(4),'black'))

# dev.off()



#########################################################################################
# Figure 4: Extracted Sea Ice Extent, by Month (both S and G)
#########################################################################################

mat_extent_and_ice = cbind(iceplus_dts[, 1:2], iceplus_dts$Latent_S, iceplus_dts$Latent_G)
colnames(mat_extent_and_ice)[3] = 'Latent_S'
colnames(mat_extent_and_ice)[4] = 'Latent_G'

mat_melt = reshape2::melt(mat_extent_and_ice, id.vars = c('Year','Month'))
mat_melt$Month = month.name[mat_melt$Month]
mat_melt$Month = factor(mat_melt$Month, levels = month.name)
mat_melt$linetype = rep(rep(c("solid","solid"), each = 40), times = 12)
mat_melt$LineSize = rep(rep(c(0.6, 0.3), each = 40), times = 12)

# png(file = ..., width = 1800, height = 2000, res = 250)

ggplot(data = mat_melt, aes(x = Year, y = value, col = variable)) +
   geom_line(size = mat_melt$LineSize, alpha = 0.7, linetype = mat_melt$linetype) +
   scale_y_continuous(breaks = breaks_fun) +
   scale_x_continuous(breaks = seq(1980, 2020, 10), minor_breaks = NULL, limits = c(1979, 2021)) +
   facet_wrap( ~ Month, ncol = 3, scale = 'free_y') +
   xlab('') + ylab('Sea Ice Extent') +
   theme_bw() +
   scale_color_manual(values = c('black','black'), labels = unname(TeX(c("$\\lambda_S = 1", "$\\lambda_G = 1"))))+
   theme(legend.position = "bottom", legend.title = element_blank(), legend.text = element_text(size = 12)) +
   guides(color = guide_legend(override.aes = list(size = c(0.6,0.3))))

# dev.off()


