bmatrix = function(x, digits=NULL, ...) {
   library(xtable)
   default_args = list(include.colnames=FALSE, only.contents=TRUE,
                       include.rownames=FALSE, hline.after=NULL, comment=FALSE,
                       print.results=FALSE)
   passed_args = list(...)
   calling_args = c(list(x=xtable(x, digits=digits)),
                    c(passed_args,
                      default_args[setdiff(names(default_args), names(passed_args))]))
   cat("\\begin{bmatrix}\n",
       do.call(print.xtable, calling_args),
       "\\end{bmatrix}\n")
}


# color for ggplot
gg_color_hue <- function(n) {
   hues = seq(15, 375, length = n + 1)
   hcl(h = hues, l = 65, c = 100)[1:n]
}


# customized y axis
breaks_fun <- function(x) {
   seq(floor(min(x)), ceiling(max(x)), by = 1)
}
