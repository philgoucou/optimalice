Optimal Combination of Arctic Sea Ice Extent Measures: A Dynamic Factor Modeling Approach
- Francis X. Diebold, Maximilian Gobel, Philippe Goulet Coulombe, Glenn D. Rudebusch and Boyuan Zhang

This version: Aug 2021

File structure:

code
- main_ICEplus_SIE.R: main source code to perform Kalman filter and construct ICE+
- graph_ICEplus_SIE.R: generate figure 1-4 in the paper


data
- MergedRawData.csv: raw series for sea ice extent (Sii, Jaxa, Bremen and Goddard)
- ice_with_dts_latent_addIntercept.csv: sea ice extent and the extracted ice+
